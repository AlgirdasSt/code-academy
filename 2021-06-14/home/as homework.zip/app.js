let salary = prompt('Įveskite bazinį užmokesčio dydį');
const people = 1761463;
const budget = 8487300000;
var	result = (salary * people) / budget * 100;
document.write(result);