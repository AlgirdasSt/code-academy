let number_A = prompt('Įveskite skaičių A');
let number_B = prompt('Įveskite skaičių B');
console.log(number_A);
console.log(number_B);
let result_1 = (+number_A +  +number_B) ;
let result_2 = (number_A - number_B) ;
let result_3 = (number_A / number_B) ;

document.write ( + 'A + B = ' + result_1 );
document.write ('A - B = ' + result_2);
document.write ('A / B liekana: ' + result_3);
